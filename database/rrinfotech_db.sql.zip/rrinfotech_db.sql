-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2023 at 06:43 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rrinfotech_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

CREATE TABLE `bank_details` (
  `b_id` int(100) NOT NULL auto_increment,
  `b_name` varchar(100) NOT NULL,
  `upi` varchar(100) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `account_holder` varchar(100) NOT NULL,
  PRIMARY KEY  (`b_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bank_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `cart_details`
--

CREATE TABLE `cart_details` (
  `crt_id` int(100) NOT NULL auto_increment,
  `u_id` varchar(100) NOT NULL,
  `pr_id` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  PRIMARY KEY  (`crt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cart_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ct_id` int(100) NOT NULL auto_increment,
  `ct_name` varchar(100) NOT NULL,
  `ct_description` varchar(100) NOT NULL,
  PRIMARY KEY  (`ct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `category`
--


-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `c_id` int(100) NOT NULL auto_increment,
  `f_name` varchar(100) NOT NULL,
  `l_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL,
  `r_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `contact_us`
--


-- --------------------------------------------------------

--
-- Table structure for table `customise_details`
--

CREATE TABLE `customise_details` (
  `co_id` int(100) NOT NULL auto_increment,
  `u_id` varchar(100) NOT NULL,
  `monitor` varchar(100) NOT NULL,
  `processor` varchar(100) NOT NULL,
  `ram` varchar(100) NOT NULL,
  `ssd` varchar(100) NOT NULL,
  `hdd` varchar(100) NOT NULL,
  `cabinet` varchar(100) NOT NULL,
  `motherboard` varchar(100) NOT NULL,
  `graphic_card` varchar(100) NOT NULL,
  `power_supply` varchar(100) NOT NULL,
  `keyboard` varchar(100) NOT NULL,
  `mouse` varchar(100) NOT NULL,
  `order_type` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `o_date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`co_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customise_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(100) NOT NULL auto_increment,
  `u_id` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  `s_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `log_in`
--

CREATE TABLE `log_in` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `u_type` varchar(100) NOT NULL,
  `s_question` varchar(100) NOT NULL,
  `s_answer` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_in`
--


-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `o_id` int(100) NOT NULL auto_increment,
  `u_id` varchar(100) NOT NULL,
  `pr_id` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `sp_id` varchar(100) NOT NULL,
  `o_date` varchar(100) NOT NULL,
  `o_time` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`o_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `pr_id` int(100) NOT NULL auto_increment,
  `sct_id` varchar(100) NOT NULL,
  `pr_name` varchar(100) NOT NULL,
  `pr_description` varchar(100) NOT NULL,
  `pr_aprice` varchar(100) NOT NULL,
  `pr_status` varchar(100) NOT NULL,
  PRIMARY KEY  (`pr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_photos`
--

CREATE TABLE `product_photos` (
  `pp_id` int(100) NOT NULL auto_increment,
  `pr_id` varchar(100) NOT NULL,
  `pr_photo1` varchar(100) NOT NULL,
  `pr_photo2` varchar(100) NOT NULL,
  `pr_photo3` varchar(100) NOT NULL,
  PRIMARY KEY  (`pp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_review`
--

CREATE TABLE `product_review` (
  `prr_id` int(100) NOT NULL auto_increment,
  `pr_id` varchar(100) NOT NULL,
  `ratings` varchar(100) NOT NULL,
  `review` varchar(100) NOT NULL,
  `u_id` varchar(100) NOT NULL,
  `prv_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`prr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_review`
--


-- --------------------------------------------------------

--
-- Table structure for table `shipping_details`
--

CREATE TABLE `shipping_details` (
  `sp_id` int(100) NOT NULL auto_increment,
  `u_id` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `landmark` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  PRIMARY KEY  (`sp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shipping_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sct_id` int(100) NOT NULL auto_increment,
  `ct_id` varchar(100) NOT NULL,
  `sct_name` varchar(100) NOT NULL,
  `sct_description` varchar(100) NOT NULL,
  PRIMARY KEY  (`sct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sub_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `u_id` int(100) NOT NULL auto_increment,
  `f_name` varchar(100) NOT NULL,
  `l_name` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY  (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `user_details`
--

